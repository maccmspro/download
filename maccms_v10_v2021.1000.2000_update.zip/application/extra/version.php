<?php
return array (
    'name' => '苹果CMS内容管理系统',
    'copyright' => 'MacCMS',
    'url' => '//github.com/maccmspro',
    'code' => '2021.1000.2000',
    'license' => '免费版',
);
?>