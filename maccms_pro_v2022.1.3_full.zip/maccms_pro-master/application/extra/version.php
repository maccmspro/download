<?php
return array (
    'name' => 'MacCMS Pro内容管理系统',
    'copyright' => 'MacCMS Pro',
    'url' => '//github.com/maccmspro',
    'code' => '2022.1.3',
    'license' => '免费版',
);
