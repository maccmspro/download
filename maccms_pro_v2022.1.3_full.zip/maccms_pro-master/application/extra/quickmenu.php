<?php
return array (
  0 => '行分隔符,###',
  1 => '示例系统模块菜单,system/config',
  2 => '示例远程地址菜单,//www.baidu.com/',
  3 => '示例插件文件菜单,/application/xxxx.html',
);